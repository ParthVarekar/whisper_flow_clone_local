"""Audio capture + normalization + chunking.

All audio is normalized to 16-bit 16 kHz mono WAV (whisper.cpp's preferred
format) before being handed to the transcription backend.

  * File input: ffmpeg converts any input format -> normalized WAV.
  * Mic input:  arecord (ALSA, usually preinstalled) or ffmpeg (-f alsa/-f pulse).
  * Chunking:   optional ffmpeg-based split for very long files. whisper.cpp
                already processes long audio in 30s windows internally, so
                chunking is OFF by default and only needed for extremely long
                recordings or for parallel/robust handling.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import wave

from .config import AudioConfig
from .errors import AudioError, BinaryNotFoundError

WAV_CODEC = "pcm_s16le"


def _which(name: str) -> str:
    path = shutil.which(name)
    if path is None:
        raise BinaryNotFoundError(name)
    return path


def _probe_duration_seconds(path: str, ffmpeg_bin: str) -> float:
    """Best-effort duration probe via ffprobe (may not be installed)."""
    ffprobe = shutil.which("ffprobe")
    if ffprobe is None:
        return 0.0
    try:
        proc = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
        )
        if proc.returncode == 0:
            return float(proc.stdout.decode("utf-8", "replace").strip() or 0.0)
    except (ValueError, OSError):
        pass
    return 0.0


def validate_wav(path: str) -> float:
    """Sanity-check a WAV file's header. Returns duration in seconds.

    Raises AudioError on corrupted/empty/non-WAV files.
    """
    if not os.path.isfile(path):
        raise AudioError(f"audio file not found: {path!r}")
    if os.path.getsize(path) < 44:
        raise AudioError(f"audio file too small to be a valid WAV: {path!r}")
    try:
        with wave.open(path, "rb") as w:
            nch = w.getnchannels()
            sampwidth = w.getsampwidth()
            framerate = w.getframerate()
            nframes = w.getnframes()
        if nch < 1 or sampwidth < 1 or framerate < 1:
            raise AudioError(f"invalid WAV params in {path!r}: ch={nch} sampwidth={sampwidth} rate={framerate}")
        if framerate not in (8000, 11025, 16000, 22050, 32000, 44100, 48000, 96000, 192000):
            # not fatal — whisper.cpp + ffmpeg resample to 16k; just note it
            pass
        return nframes / framerate if framerate else 0.0
    except wave.Error as exc:
        raise AudioError(f"corrupted WAV header in {path!r}: {exc}") from exc
    except OSError as exc:
        raise AudioError(f"cannot read {path!r}: {exc}") from exc


def normalize_file(cfg: AudioConfig, input_path: str, *, verbose: bool = False) -> str:
    """Convert any audio file to a normalized 16kHz mono WAV. Returns the new path.

    If the input is already a compliant WAV, ffmpeg is still run (cheap and
    guarantees format correctness). The output lives in a temp dir.
    """
    if not os.path.isfile(input_path):
        raise AudioError(f"input audio file not found: {input_path!r}")
    ffmpeg = _which(cfg.ffmpeg_bin)

    tmp = tempfile.NamedTemporaryFile(
        prefix="wf_norm_", suffix=".wav", delete=False, dir=tempfile.gettempdir()
    )
    out_path = tmp.name
    tmp.close()

    cmd = [
        ffmpeg, "-y", "-i", input_path,
        "-ar", str(cfg.sample_rate),
        "-ac", str(cfg.channels),
        "-c:a", WAV_CODEC,
        out_path,
    ]
    if verbose:
        print(f"[audio] normalize: {' '.join(cmd)}", flush=True)
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode != 0 or not os.path.isfile(out_path) or os.path.getsize(out_path) == 0:
        stderr = proc.stderr.decode("utf-8", "replace")
        os.path.exists(out_path) and os.remove(out_path)
        raise AudioError(f"ffmpeg normalization failed for {input_path!r}:\n{stderr.strip()[:800]}")
    return out_path


def capture_mic(cfg: AudioConfig, duration: float, *, verbose: bool = False) -> str:
    """Record from the microphone for `duration` seconds. Returns a WAV path.

    Backend selection (cfg.mic_backend='auto' picks the first available):
      - sounddevice (optional `pip install whisper-flow[mic]`): cross-platform, default device auto
      - arecord: Linux (ALSA, preinstalled on most distros)
      - ffmpeg:   cross-platform fallback with per-OS input format:
          Linux:   -f pulse | -f alsa  (pulse preferred if pactl present)
          macOS:   -f avfoundation -i ":default"  (documented default alias)
          Windows: -f dshow -i audio="<device>"  (use list_devices_dshow() to enumerate)

    duration <= 0 records until Ctrl+C (ffmpeg/sounddevice only; arecord needs -d).
    """
    backend = cfg.mic_backend
    if backend == "auto":
        backend = _auto_mic_backend()

    if backend == "sounddevice":
        return _capture_sounddevice(cfg, duration, verbose=verbose)
    if backend == "arecord":
        return _capture_arecord(cfg, duration, verbose=verbose)
    return _capture_ffmpeg(cfg, duration, verbose=verbose)


def _auto_mic_backend() -> str:
    # sounddevice preferred if installed (single codepath, default device)
    try:
        import sounddevice  # noqa: F401
        return "sounddevice"
    except ImportError:
        pass
    if sys.platform == "linux" and shutil.which("arecord"):
        return "arecord"
    return "ffmpeg"


def _capture_sounddevice(cfg: AudioConfig, duration: float, *, verbose: bool) -> str:
    try:
        import sounddevice as sd
    except ImportError as exc:
        raise AudioError(
            "sounddevice backend selected but the package is not installed; "
            "run `pip install sounddevice` (or whisper-flow[mic])"
        ) from exc
    tmp = tempfile.NamedTemporaryFile(
        prefix="wf_mic_", suffix=".wav", delete=False, dir=tempfile.gettempdir()
    )
    out_path = tmp.name
    tmp.close()

    fs, ch = cfg.sample_rate, cfg.channels
    total_frames = int(duration * fs) if (duration and duration > 0) else None
    if verbose:
        print(f"[audio] mic (sounddevice): fs={fs} ch={ch} duration={duration}", flush=True)
    try:
        # blocking capture; if total_frames is None, records until KeyboardInterrupt
        data = sd.rec(total_frames, samplerate=fs, channels=ch, dtype="int16",
                      device=_sd_device(cfg.mic_device))
        sd.wait()
    except KeyboardInterrupt:
        sd.stop()
    except Exception as exc:  # sd.PortAudioError etc.
        raise AudioError(f"sounddevice capture failed: {exc}") from exc

    import numpy as _np  # sounddevice returns a numpy array; declared optional dep
    arr = data if isinstance(data, _np.ndarray) else _np.array(data)
    if arr.size == 0:
        raise AudioError("sounddevice captured no frames (mic may be missing or muted)")
    with wave.open(out_path, "wb") as w:
        w.setnchannels(ch)
        w.setsampwidth(2)
        w.setframerate(fs)
        w.writeframes(arr.tobytes())
    return out_path


def _sd_device(spec: str):
    """Resolve a sounddevice device spec. 'default' -> None (let PortAudio pick)."""
    if not spec or spec == "default":
        return None
    try:
        return int(spec)
    except ValueError:
        return spec


def _capture_arecord(cfg: AudioConfig, duration: float, *, verbose: bool) -> str:
    arecord = _which(cfg.arecord_bin)
    tmp = tempfile.NamedTemporaryFile(
        prefix="wf_mic_", suffix=".wav", delete=False, dir=tempfile.gettempdir()
    )
    out_path = tmp.name
    tmp.close()

    # -f S16_LE -r <rate> -c <ch>  produces 16-bit PCM at the exact rate/channels.
    # (Previous code used '-f cd' which is 44100/16-bit/stereo and contradicted -r 16000.)
    cmd = [
        arecord,
        "-D", cfg.mic_device,
        "-f", "S16_LE",
        "-r", str(cfg.sample_rate),
        "-c", str(cfg.channels),
        "-t", "wav",
    ]
    if duration and duration > 0:
        cmd += ["-d", str(int(round(duration)))]
    cmd.append(out_path)

    if verbose:
        print(f"[audio] mic (arecord): {' '.join(cmd)}", flush=True)
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    except KeyboardInterrupt:
        if os.path.isfile(out_path):
            return out_path
        raise AudioError("interrupted before any audio was captured")
    if proc.returncode != 0 or not os.path.isfile(out_path) or os.path.getsize(out_path) == 0:
        stderr = proc.stderr.decode("utf-8", "replace")
        raise AudioError(
            f"arecord failed (code {proc.returncode}).\n{stderr.strip()[:800]}\n"
            f"  hint: check device {cfg.mic_device!r} with `arecord -l` / `pactl list sources`."
        )
    # arecord was given correct rate/channels already; re-encode codec just in case.
    return _ensure_codec(cfg, out_path, verbose=verbose)


def _capture_ffmpeg(cfg: AudioConfig, duration: float, *, verbose: bool) -> str:
    ffmpeg = _which(cfg.ffmpeg_bin)
    tmp = tempfile.NamedTemporaryFile(
        prefix="wf_mic_", suffix=".wav", delete=False, dir=tempfile.gettempdir()
    )
    out_path = tmp.name
    tmp.close()

    input_args = _ffmpeg_mic_input_args(cfg)
    cmd = [ffmpeg, "-y"] + input_args + [
        "-ar", str(cfg.sample_rate),
        "-ac", str(cfg.channels),
        "-c:a", WAV_CODEC,
    ]
    if duration and duration > 0:
        cmd += ["-t", str(duration)]
    cmd.append(out_path)

    if verbose:
        print(f"[audio] mic (ffmpeg {sys.platform}): {' '.join(cmd)}", flush=True)
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    except KeyboardInterrupt:
        if os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
            return out_path
        raise AudioError("interrupted before any audio was captured")
    if proc.returncode != 0 or not os.path.isfile(out_path) or os.path.getsize(out_path) == 0:
        stderr = proc.stderr.decode("utf-8", "replace")
        raise AudioError(
            f"ffmpeg mic capture failed (code {proc.returncode}).\n{stderr.strip()[:800]}"
        )
    return out_path


def _ffmpeg_mic_input_args(cfg: AudioConfig) -> list[str]:
    """Build ffmpeg input args per OS. Uses cfg.mic_device ('default' = OS default)."""
    dev = cfg.mic_device or "default"
    if sys.platform == "darwin":
        # AVFoundation: "video:audio". ":default" = no video, default audio input.
        # ffmpeg-devices.html documents the 'default' alias for avfoundation.
        return ["-f", "avfoundation", "-i", f":{dev}"]
    if sys.platform == "win32":
        # DirectShow. No 'default' alias — user must pass a device name string
        # (use `whisper-flow list-devices` to enumerate).
        if dev == "default":
            raise AudioError(
                "Windows ffmpeg/dshow requires an explicit device name. "
                "Run `whisper-flow list-devices` to enumerate, then set "
                "--mic-device \"Microphone (Your Device)\"."
            )
        return ["-f", "dshow", "-i", f"audio={dev}"]
    # Linux: prefer pulse (if pactl present, i.e. PulseAudio/PipeWire-pulse running),
    # fall back to ALSA.
    if shutil.which("pactl") is not None:
        return ["-f", "pulse", "-i", dev]
    return ["-f", "alsa", "-i", dev]


def list_devices_dshow(cfg: AudioConfig) -> list[str]:
    """Windows only: parse `ffmpeg -list_devices true -f dshow -i dummy` stderr.
    Returns a list of audio input device name strings."""
    ffmpeg = _which(cfg.ffmpeg_bin)
    # ffmpeg exits non-zero when listing devices; that's expected.
    proc = subprocess.run(
        [ffmpeg, "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )
    text = proc.stderr.decode("utf-8", "replace")
    devices: list[str] = []
    in_audio = False
    for line in text.splitlines():
        low = line.lower()
        if "directshow audio" in low:
            in_audio = True
            continue
        if "directshow video" in low:
            in_audio = False
            continue
        if in_audio and '"' in line:
            # crude: extract the quoted device name
            parts = line.split('"')
            if len(parts) >= 2:
                devices.append(parts[1])
    return devices


def _ensure_codec(cfg: AudioConfig, path: str, *, verbose: bool) -> str:
    """Re-encode to guaranteed pcm_s16le if needed. Usually a no-op passthrough."""
    ffmpeg = _which(cfg.ffmpeg_bin)
    tmp = tempfile.NamedTemporaryFile(
        prefix="wf_micc_", suffix=".wav", delete=False, dir=tempfile.gettempdir()
    )
    out_path = tmp.name
    tmp.close()
    cmd = [ffmpeg, "-y", "-i", path, "-c:a", WAV_CODEC, out_path]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode == 0 and os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
        os.remove(path)
        return out_path
    # fall back to the original capture
    os.path.exists(out_path) and os.remove(out_path)
    return path


def chunk_audio(cfg: AudioConfig, wav_path: str, *, verbose: bool = False) -> list[str]:
    """Optionally split a WAV into <= chunk_seconds chunks. Returns [wav_path] if disabled."""
    if cfg.chunk_seconds and cfg.chunk_seconds > 0:
        dur = _probe_duration_seconds(wav_path, cfg.ffmpeg_bin)
        if 0 < dur <= cfg.chunk_seconds:
            return [wav_path]
        return _split(wav_path, cfg.chunk_seconds, cfg, verbose=verbose)
    return [wav_path]


def _split(wav_path: str, chunk_seconds: int, cfg: AudioConfig, *, verbose: bool) -> list[str]:
    ffmpeg = _which(cfg.ffmpeg_bin)
    out_dir = tempfile.mkdtemp(prefix="wf_chunks_")
    pattern = os.path.join(out_dir, "chunk_%04d.wav")
    cmd = [
        ffmpeg, "-y", "-i", wav_path,
        "-f", "segment",
        "-segment_time", str(chunk_seconds),
        "-c", "copy",
        pattern,
    ]
    if verbose:
        print(f"[audio] chunk: {' '.join(cmd)}", flush=True)
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode != 0:
        stderr = proc.stderr.decode("utf-8", "replace")
        # If segment copy fails (e.g. codec mismatch), fall back to whole file.
        if verbose:
            print(f"[audio] chunking failed, using whole file: {stderr.strip()[:200]}", flush=True)
        return [wav_path]
    chunks = sorted(
        os.path.join(out_dir, f) for f in os.listdir(out_dir)
        if f.endswith(".wav") and os.path.getsize(os.path.join(out_dir, f)) > 0
    )
    return chunks or [wav_path]
